<h2>Admin Dashboard</h2>
<p>Welcome, <?= esc(session('auth_user.name')) ?></p>
<p><a href="/logout">Logout</a></p>
