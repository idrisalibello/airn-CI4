<h2>Reviewer Dashboard</h2>
<p><a href="/logout">Logout</a></p>
