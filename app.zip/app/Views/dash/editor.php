<h2>Editor Dashboard</h2>
<p><a href="/logout">Logout</a></p>
