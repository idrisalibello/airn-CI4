<h2>Author Dashboard</h2>
<p><a href="/logout">Logout</a></p>
